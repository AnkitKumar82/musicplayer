package com.example.musicplayer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.NestedScrollView;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final String [] PERMISSIONS = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.READ_PHONE_STATE
    };
    private byte[] art;
    public ListView listView;
    public ImageView album_art;
    public TextAdapter textAdapter;
    private int previousSongPosition;
    private Thread playerThread;
    private static final int REQUEST_PERMISSIONS = 12345;
    private static final int PERMISSIONS_COUNT = 2;
    private boolean isMusicPlayerInit;
    private List <String> musicFilesList;
    private int songPosition;
    private boolean playerRunning;
    private MediaPlayer mp;
    private int playingPosition;
    private TextView songPositionTextView;
    private TextView songDurationTextView;
    private SeekBar seekBar;
    private boolean playerThreadRunning;
    private TextView song_album,song_name,song_artist;
    private MediaMetadataRetriever metaRetriver;
    PhoneStateListener phoneStateListener = new PhoneStateListener() {
        @Override
        public void onCallStateChanged(int state, String incomingNumber) {
            if (state == TelephonyManager.CALL_STATE_RINGING) {
                if(playerRunning) {
                    findViewById(R.id.play_pause).performClick();
                }
            } else if(state == TelephonyManager.CALL_STATE_IDLE) {
                //Not in call: Play music
            } else if(state == TelephonyManager.CALL_STATE_OFFHOOK) {
                //A call is dialing, active or on hold
            }
            super.onCallStateChanged(state, incomingNumber);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        song_album = findViewById(R.id.playing_album);
        song_name = findViewById(R.id.playing_song);
        songPositionTextView = findViewById(R.id.currentPosition);
        songDurationTextView = findViewById(R.id.songDuration);
        song_artist = findViewById(R.id.song_artist);
        seekBar = findViewById(R.id.seekBar);
        album_art = findViewById(R.id.album_art);
        listView = findViewById(R.id.listView);
        playerThreadRunning = false;
        isMusicPlayerInit= false;
    }
    @SuppressLint("NewApi")
    private boolean arePermissionsDenied(){
        for(int i=0;i<PERMISSIONS_COUNT;i++){
            if(checkSelfPermission(PERMISSIONS[i])!=PackageManager.PERMISSION_GRANTED){
                return true;
            }
        }
        return false;
    }
    @SuppressLint("NewApi")
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(arePermissionsDenied()){
            ((ActivityManager) (this.getSystemService(ACTIVITY_SERVICE))).clearApplicationUserData();
            recreate();
        }
        else{
            onResume();
        }
    }
    private void addMusicFilesFrom(String dirPath){
        final File musicDir = new File(dirPath);
        if(!musicDir.exists()){
            musicDir.mkdir();
            return;
        }
        final File [] files = musicDir.listFiles();
        for(File file :files){
            final String path = file.getAbsolutePath();
            if(path.endsWith(".mp3")){
                musicFilesList.add(path);
            }
        }
    }
    private void fillMusicList(){
        musicFilesList.clear();
        addMusicFilesFrom(String.valueOf(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)));
        addMusicFilesFrom(String.valueOf(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)));
    }
    private int playMusicFile(String path, final int position){
        try {
            mp.stop();
            mp.release();
            mp = null;
        }
        catch (Exception e){
        }
        try{
            mp = new MediaPlayer();
            mp.setDataSource(path);
            mp.prepare();
            if(isMusicPlayerInit) {
                mp.start();
                isMusicPlayerInit = true;
            }
            metaRetriver = new MediaMetadataRetriever();
            metaRetriver.setDataSource(path);
            try {
                song_name.setText(metaRetriver.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE));
            } catch (Exception e){
                song_name.setText("Unknown Title");
            }
            try{
                song_album.setText(metaRetriver.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM));
            }catch (Exception e){
                song_album.setText("Unknown Album");
            }
            try{
                art = metaRetriver.getEmbeddedPicture();
                Bitmap songImage = BitmapFactory
                        .decodeByteArray(art, 0, art.length);
                album_art.setImageBitmap(songImage);
            }
            catch (Exception e){
                album_art.setImageResource(R.drawable.song_background);
            }
            try{
                song_artist.setText(metaRetriver.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST));
            }catch (Exception e){
                song_artist.setText("Unknown Artist");
            }
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                public void onCompletion(MediaPlayer mp) {
                    playingPosition = (position + 1) % (musicFilesList.size());
                    setPlayerAttributes(playingPosition);
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
        return mp.getDuration();
    }
    private void startingPlayerThread(){
        playerThread = new Thread() {
            public void run() {
                while (!isDestroyed()) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            songPosition = mp.getCurrentPosition() / 1000;
                            songPositionTextView.setText(String.valueOf(songPosition < 600 ? "0" : "") + String.valueOf(songPosition / 60) + ":" + String.valueOf(songPosition % 60 < 10 ? "0" : "") + (String.valueOf(songPosition % 60)));
                            seekBar.setProgress(songPosition);
                        }
                    });
                    synchronized (playerThread) {
                        while (!playerRunning) {
                            try {
                                playerThread.wait();
                            } catch (InterruptedException e) {
                            }
                        }
                    }
                    try {
                        playerThread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        };
        playerThread.start();
    }
    private void setPlayerAttributes(final int position){
        final String musicFilePath = musicFilesList.get(position);  //position of current clicked line
        final int songDuration = playMusicFile(musicFilePath,position) / 1000;
        seekBar.setMax(songDuration);
        seekBar.setProgress(0);
        playingPosition = position;
        songPositionTextView.setText("00:00");
        songDurationTextView.setText(String.valueOf(songDuration<600?"0":"")+String.valueOf(songDuration/60)+":"+String.valueOf(songDuration%60<10?"0":"")+(String.valueOf(songDuration%60)));
        if(!playerThreadRunning){
            playerThreadRunning = true;
            startingPlayerThread();
        }
        synchronized (playerThread) {
            if (isMusicPlayerInit){
                playerRunning = true;
                ImageView imageView = findViewById(R.id.play_pause);
                imageView.setImageResource(R.drawable.ic_pause);
                playerThread.notifyAll();
            }
        }
    }
    @Override
    protected void onDestroy(){
        super.onDestroy();
        mp.release();
        mp.stop();
        mp=null;
        TelephonyManager mgr = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        if(mgr != null) {
            mgr.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);
        }
    }
    @Override
    protected void onResume(){
        super.onResume();
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && arePermissionsDenied()){
            requestPermissions(PERMISSIONS,REQUEST_PERMISSIONS);
            return ;
        }
        if(!isMusicPlayerInit) {
            listView = findViewById(R.id.listView);
            textAdapter = new TextAdapter();
            musicFilesList = new ArrayList<>();
            fillMusicList(); // fill music list in app
            if (musicFilesList.size() != 0) {
                textAdapter.setData(musicFilesList);
                listView.setAdapter(textAdapter);
                final SeekBar seekBar = findViewById(R.id.seekBar);
                seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    int songProgress;

                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        songProgress = progress;
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        mp.seekTo(songProgress * 1000);
                        songPosition = songProgress;
                    }
                });
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        setPlayerAttributes(position);
                    }
                });
                setPlayerAttributes(0);
                isMusicPlayerInit = true;
            }
            else{
                LinearLayout linearLayout = findViewById(R.id.playerView);
                linearLayout.setVisibility(View.GONE);
                TextView songList = findViewById(R.id.songsList);
                songList.setText("No Music Files Found");
                Toast toast = Toast.makeText(getApplicationContext(),"No Music Files Found",Toast.LENGTH_LONG*2);
                toast.show();
            }
        }
    }
    public void resumeOrPause(View view){
        ImageView imageView = findViewById(R.id.play_pause);
        if(mp.isPlaying()){
            synchronized (playerThread) {
                playerRunning = false;
                playerThread.notifyAll();
            }
            mp.pause();
            imageView.setImageResource(R.drawable.ic_play);
        }
        else{
            imageView.setImageResource(R.drawable.ic_pause);
            synchronized (playerThread){
                playerRunning = true;
                playerThread.notifyAll();
            }
            isMusicPlayerInit=true;
            mp.start();
        }
    }
    public void skipPrev(View view) {
        playingPosition = (playingPosition-(playingPosition<=0?(-musicFilesList.size()+1):1))%(musicFilesList.size());
        setPlayerAttributes(playingPosition);
    }
    public void skipNext(View view) {
        playingPosition = (playingPosition+1)%(musicFilesList.size());
        setPlayerAttributes(playingPosition);
    }
    public void showHideList(View view) {
        if(listView.getVisibility()==View.GONE){
            listView.setVisibility(View.VISIBLE);
        }
        else{
            listView.setVisibility(View.GONE);
        }
    }
    class TextAdapter extends BaseAdapter{
        private List<String> data = new ArrayList<>();
        void setData(List <String> mData){
            data.clear();
            data.addAll(mData);
            notifyDataSetChanged();
        }
        @Override
        public int getCount(){
            return data.size();
        }
        @Override
        public String getItem(int position){
            return null;
        }
        @Override
        public long getItemId(int position){
            return position;
        }
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if(convertView == null){
                convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item,parent,false);
                convertView.setTag(new ViewHolder((TextView) convertView.findViewById(R.id.myItem)));
            }
            ViewHolder holder = (ViewHolder) convertView.getTag();
            final String item = data.get(position);
            holder.info.setText(item.substring(item.lastIndexOf('/')+1));
            return convertView;
        }
        class ViewHolder{
            TextView info;
            ViewHolder(TextView mInfo){
                info = mInfo;
            }
        }
    }

}














